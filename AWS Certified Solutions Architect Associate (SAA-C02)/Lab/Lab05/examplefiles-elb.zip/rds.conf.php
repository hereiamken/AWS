<?php
$RDS_URL="";
$RDS_DB="aws201";
$RDS_user="awsuser";
$RDS_pwd="aws201pwd";
?>
